#import <Foundation/Foundation.h>

@interface Calculator : NSObject

@end
